export const INITIAL_DISPLAY_MODE = 'list';
export const DEFAULT_USER_ROLE = 'free';
