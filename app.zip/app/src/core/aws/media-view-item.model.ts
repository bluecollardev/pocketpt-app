export interface MediaViewItem {
  title: string;
  description: string;
  image: string;
}
